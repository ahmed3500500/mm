package com.example.islamicapp.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.islamicapp.R
import com.example.islamicapp.data.QuranData
import com.example.islamicapp.data.SurahItem
import com.example.islamicapp.quran.QuranRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun QuranTextScreen(modifier: Modifier = Modifier) {
    var selectedSurah by remember { mutableStateOf<SurahItem?>(null) }

    BackHandler(enabled = selectedSurah != null) {
        selectedSurah = null
    }

    if (selectedSurah != null) {
        SurahDetailView(
            surahItem = selectedSurah!!,
            onBack = { selectedSurah = null }
        )
    } else {
        SurahListView(
            onSurahClick = { selectedSurah = it },
            modifier = modifier
        )
    }
}

@Composable
fun SurahListView(
    onSurahClick: (SurahItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val surahs = remember { QuranData.getSurahList() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { QuranRepository(context) }

    var offlineReady by remember { mutableStateOf(false) }
    var isDownloading by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }
    var progressValue by remember { mutableStateOf(0f) }
    var tafsirKey by remember { mutableStateOf<String?>(null) }
    var tafsirTitle by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        offlineReady = withContext(Dispatchers.IO) { repo.isQuranAvailableOffline() }
        if (tafsirKey == null) {
            val (k, t) = withContext(Dispatchers.IO) { repo.chooseDefaultArabicTafsirKey() }
            tafsirKey = k
            tafsirTitle = t
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg_home),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                text = "القرآن الكريم (قراءة)",
                style = MaterialTheme.typography.headlineSmall.copy(
                    color = Color(0xFFFFD700),
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14402A).copy(alpha = 0.92f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (offlineReady) "جاهز بدون إنترنت ✅ (القرآن + تفسير: ${tafsirTitle ?: ""})" else "لم يتم تحميل القرآن والتفسير بعد",
                        color = Color.White,
                        fontSize = 13.sp
                    )

                    if (!offlineReady) {
                        Button(
                            onClick = {
                                if (isDownloading) return@Button
                                isDownloading = true
                                progressValue = 0f
                                progressText = "بدء التحميل..."
                                val key = tafsirKey
                                val title = tafsirTitle
                                scope.launch {
                                    withContext(Dispatchers.IO) {
                                        repo.downloadQuranText { s ->
                                            val v = s / 114f
                                            progressValue = v * 0.5f
                                            progressText = "تحميل القرآن: سورة $s/114"
                                        }
                                        if (key != null && title != null) {
                                            repo.downloadTafsir(key, title) { s ->
                                                val v = s / 114f
                                                progressValue = 0.5f + (v * 0.5f)
                                                progressText = "تحميل التفسير: سورة $s/114"
                                            }
                                        }
                                    }
                                    offlineReady = true
                                    isDownloading = false
                                    progressText = "تم التحميل ✅"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700))
                        ) {
                            Text(text = "تحميل القرآن + التفسير للاستخدام دون إنترنت", color = Color(0xFF062D1A))
                        }

                        if (isDownloading) {
                            LinearProgressIndicator(progress = progressValue, modifier = Modifier.fillMaxWidth())
                            Text(text = progressText, color = Color(0xFFFFD700), fontSize = 12.sp)
                        }
                    }
                }
            }
            
            Card(
                modifier = Modifier.fillMaxSize(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F3B24).copy(alpha = 0.9f)),
                shape = RoundedCornerShape(24.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(surahs) { surah ->
                        SurahTextRow(
                            surah = surah,
                            onClick = { onSurahClick(surah) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SurahTextRow(surah: SurahItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF14402A)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClick() }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = surah.name, color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    text = "رقم السورة: ${surah.number}",
                    color = Color(0xFFFFD700),
                    fontSize = 12.sp
                )
            }
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700))
            ) {
                Text(text = "قراءة", color = Color(0xFF062D1A))
            }
        }
    }
}

@Composable
fun SurahDetailView(
    surahItem: SurahItem,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val repo = remember { QuranRepository(context) }
    var ayahsText by remember(surahItem.number) { mutableStateOf<List<String>>(emptyList()) }
    var tafsirText by remember(surahItem.number) { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var showTafsir by remember { mutableStateOf(true) }
    var offlineReady by remember { mutableStateOf(false) }
    var tafsirTitle by remember { mutableStateOf<String?>(null) }
    var tafsirKey by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(surahItem.number) {
        offlineReady = withContext(Dispatchers.IO) { repo.isQuranAvailableOffline() }
        val (k, t) = withContext(Dispatchers.IO) { repo.chooseDefaultArabicTafsirKey() }
        tafsirKey = k
        tafsirTitle = t
        if (offlineReady) {
            val ayahs = withContext(Dispatchers.IO) { repo.getSurahAyahs(surahItem.number) }
            ayahsText = ayahs.sortedBy { it.ayah }.map { "${it.ayah}. ${it.text}" }
            val tfs = withContext(Dispatchers.IO) {
                repo.getTafsirForSurah(k, surahItem.number)
            }
            tafsirText = tfs.associate { it.ayah to it.text }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg_home),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = surahItem.name,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = Color(0xFFFFD700),
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.weight(0.2f))
            }

            Card(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF5E6)),
                shape = RoundedCornerShape(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (!offlineReady) {
                        item {
                            Text(
                                text = "لا يوجد قرآن/تفسير محمّل للاستخدام دون إنترنت. ارجع للشاشة السابقة واضغط: تحميل القرآن + التفسير.",
                                color = Color.Black,
                                fontSize = 16.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    } else {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "التفسير: ${tafsirTitle ?: ""}",
                                    color = Color(0xFF14402A),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Button(
                                    onClick = { showTafsir = !showTafsir },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF14402A))
                                ) {
                                    Text(text = if (showTafsir) "إخفاء التفسير" else "إظهار التفسير", color = Color.White)
                                }
                            }
                        }

                        items(ayahsText) { line ->
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = line,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = Color.Black,
                                        lineHeight = 30.sp,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                if (showTafsir) {
                                    val ayahNo = line.substringBefore('.').toIntOrNull()
                                    val tafsir = if (ayahNo != null) tafsirText[ayahNo] else null
                                    if (!tafsir.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = tafsir,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = Color(0xFF14402A),
                                                lineHeight = 22.sp,
                                                fontSize = 15.sp
                                            ),
                                            textAlign = TextAlign.Start,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
