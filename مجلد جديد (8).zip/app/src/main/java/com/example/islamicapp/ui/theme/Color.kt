package com.example.islamicapp.ui.theme

import androidx.compose.ui.graphics.Color

val DarkGreen = Color(0xFF062D1A)
val EmeraldGreen = Color(0xFF0B5B34)
val IslamicGold = Color(0xFFFFD700)
val SurfaceGreen = Color(0xFF0F3B24)

