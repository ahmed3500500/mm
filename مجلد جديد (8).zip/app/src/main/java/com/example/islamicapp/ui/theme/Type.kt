package com.example.islamicapp.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()

