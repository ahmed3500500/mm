package com.example.islamicapp.quran

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

enum class Reciter(val displayName: String, val baseUrl: String, val extraPath: String = "") {
    AL_AFASY("مشاري العفاسي", "https://server8.mp3quran.net/afs/"),
    SAAD_GHAMDI("سعد الغامدي", "https://server7.mp3quran.net/s_gmd/"),
    ABDUL_BASIT("عبد الباسط عبد الصمد", "https://server7.mp3quran.net/basit/"),
    MAHER("ماهر المعيقلي", "https://server12.mp3quran.net/maher/"),
    SUDAYS("عبد الرحمن السديس", "https://server11.mp3quran.net/sds/"),
    SHURAIM("سعود الشريم", "https://server7.mp3quran.net/shur/"),
    AJMI("أحمد العجمي", "https://server10.mp3quran.net/ajm/", "128/")
}

object QuranPlayer {
    private var mediaPlayer: MediaPlayer? = null
    var currentReciter: Reciter = Reciter.AL_AFASY
        private set

    fun setReciter(reciter: Reciter) {
        currentReciter = reciter
    }

    fun playSurah(context: Context, surahNumber: Int) {
        stop()
        val url = buildUrlForSurah(surahNumber)
        val player = MediaPlayer()
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()
        )
        player.setDataSource(url)
        player.setOnPreparedListener { it.start() }
        player.setOnCompletionListener {
            stop()
        }
        mediaPlayer = player
        player.prepareAsync()
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private fun buildUrlForSurah(number: Int): String {
        val formatted = number.toString().padStart(3, '0')
        return currentReciter.baseUrl + currentReciter.extraPath + "$formatted.mp3"
    }
}
